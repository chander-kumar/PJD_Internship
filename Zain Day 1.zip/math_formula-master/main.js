// Euler's formula
var e = math.e;
var pi = math.pi;
var i = math.i;
var num = math.im(i)*pi;
var euler = math.pow(e,num)+1; 

// console.log(e);
// console.log(pi);
// console.log(i);
console.log(euler);